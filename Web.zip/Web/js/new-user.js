$(document).ready(function(){
  $('#txt-tel').mask('000-0000-0000', {placeholder: '000-0000-0000'}); //placeholder
});
