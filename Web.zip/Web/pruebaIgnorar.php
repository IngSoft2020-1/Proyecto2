<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <table>
      <tbody>
        <tr>
          <td>Jose Vazquez</td>
        </tr>
        <tr>
          <td>Telefono</td>
          <td>664646</td>
        </tr>
        <tr>
          <td>Fecha</td>
          <td>02-12-2020</td>
        </tr>
        <tr>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td>Juan Jose</td>
        </tr>
        <tr>
          <td>Telefono</td>
          <td>664646</td>
        </tr>
        <tr>
          <td>Fecha</td>
          <td>02-12-2020</td>
        </tr>
      </tbody>
    </table>
  </body>
</html>
